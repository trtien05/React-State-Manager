### React Redux Saga Starter - Typescript (Hỏi Dân IT)

Template này được sử dụng cho series React State Manager của tác giả Hỏi Dân IT (Eric)

Các bước cần làm:

1. Clone dự án
2. Cài đặt các thư viện cần thiết: npm i
3. Chạy dự án với câu lệnh: npm run dev

 
Truy cập:  http://localhost:5173/
